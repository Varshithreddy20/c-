﻿using CRAVENEST.Model;
using CRAVENEST.Repository.Interface;
using CRAVENEST.Service.Interfce;

namespace CRAVENEST.Service.Concrete
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public int SignUp(User user)
        {
            return _userRepository.SignUp(user);
        }

        public (bool, string, int) Login(string email, string password)
        {
            var response = _userRepository.Login(email, password);
            return response;
        }
    }
}
