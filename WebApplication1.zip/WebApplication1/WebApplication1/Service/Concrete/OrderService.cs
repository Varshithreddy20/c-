﻿using CRAVENEST.Model;
using CRAVENEST.Repository.Interface;
using CRAVENEST.Service.Interface;
using CRAVENEST.Utilities.Eums;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CRAVENEST.Service.Concrete
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository repository;
        private readonly ILogger<OrderService> logger;

        public OrderService(IOrderRepository repository, ILogger<OrderService> logger)
        {
            this.repository = repository;
            this.logger = logger;
        }

        public async Task<int> CreateOrder(Order order)
        {
            try
            {
                return await repository.CreateOrder(order);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error creating order");
                throw;  // Let the exception bubble up instead of returning default values
            }
        }

        public async Task<Order> GetOrderById(int id)
        {
            try
            {
                return await repository.GetOrderById(id);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Error getting order with id {id}");
                throw;  // Avoid returning null for errors
            }
        }

        public async Task<List<Order>> GetAllOrders()
        {
            try
            {
                return await repository.GetAllOrders();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error getting all orders");
                throw;  // Avoid returning empty list for errors
            }
        }

        public async Task<ResultStatus> UpdateOrderStatus(int id, string status)
        {
            try
            {
                return await repository.UpdateOrderStatus(id, status);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Error updating status for order with id {id}");
                return ResultStatus.Failed;
            }
        }
    }
}
