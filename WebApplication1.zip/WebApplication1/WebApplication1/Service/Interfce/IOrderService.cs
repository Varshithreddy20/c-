﻿using CRAVENEST.Model;
using CRAVENEST.Utilities.Eums;

namespace CRAVENEST.Service.Interface
{
    public interface IOrderService
    {
        Task<int> CreateOrder(Order order); 
        Task<Order> GetOrderById(int id);
        Task<List<Order>> GetAllOrders();
        Task<ResultStatus> UpdateOrderStatus(int id, string status);
    }
}
