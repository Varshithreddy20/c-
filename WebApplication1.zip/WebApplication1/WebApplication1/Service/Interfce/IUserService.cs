﻿using CRAVENEST.Model;

namespace CRAVENEST.Service.Interfce
{
    public interface IUserService
    {
        int SignUp(User user);
        (bool, string, int) Login(string email, string password);
    }
}
