﻿using CRAVENEST.Model;
using CRAVENEST.Utilities.Eums;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface IOrderRepository
{
    Task<int> CreateOrder(Order order);
    Task<Order> GetOrderById(int id);
    Task<List<Order>> GetAllOrders();
    Task<ResultStatus> UpdateOrderStatus(int id, string status);
}
