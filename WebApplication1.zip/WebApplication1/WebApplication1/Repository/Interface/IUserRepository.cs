﻿using CRAVENEST.Model;

namespace CRAVENEST.Repository.Interface
{
    public interface IUserRepository
    {
       
            int SignUp(User user);
            (bool, string, int) Login(string email, string password);
        
    }
}
