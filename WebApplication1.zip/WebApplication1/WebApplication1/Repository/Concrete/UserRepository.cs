﻿using CRAVENEST.Model;
using CRAVENEST.Repository.Interface;
using System.Data;
using CRAVENEST.Repository;
using System.Data.SqlClient;

namespace CRAVENEST.Repository.Concrete
{

    public class UserRepository : IUserRepository
    {
        private readonly string _connectionString;

        public UserRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public int SignUp(User user)
        {
            using SqlConnection connection = new(_connectionString);
            SqlCommand command = new SqlCommand("dbo.UserSignup", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@Name", user.Name);

            command.Parameters.AddWithValue("@EmailId", user.EmailId);
            command.Parameters.AddWithValue("@Password", user.Password);


            command.Parameters.AddWithValue("@Role", 1);

            SqlParameter statusOutput = new("@StatusOutput", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            command.Parameters.Add(statusOutput);



            connection.Open();
            command.ExecuteNonQuery();

            return (int)statusOutput.Value;
        }

        public (bool, string, int) Login(string email, string password)
        {
            using SqlConnection connection = new(_connectionString);
            SqlCommand command = new("dbo.UserLogin", connection)
            {
                CommandType = CommandType.StoredProcedure
            };

            command.Parameters.AddWithValue("@EmailId", email);
            command.Parameters.AddWithValue("@Password", password);

            SqlParameter tokenOutput = new("@Token", SqlDbType.NVarChar, 255)
            {
                Direction = ParameterDirection.Output
            };
            command.Parameters.Add(tokenOutput);

            SqlParameter statusOutput = new("@StatusOutput", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            command.Parameters.Add(statusOutput);

            SqlParameter roleOutput = new("@Role", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            command.Parameters.Add(roleOutput);

            connection.Open();
            command.ExecuteNonQuery();

            bool success = (int)statusOutput.Value == 1;
            string token = tokenOutput.Value != DBNull.Value ? tokenOutput.Value.ToString() : string.Empty;
            int role = (int)roleOutput.Value;

            return (success, token, role);

        }
    }
}


