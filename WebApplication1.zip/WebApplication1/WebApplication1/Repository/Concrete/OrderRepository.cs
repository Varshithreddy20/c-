﻿using CRAVENEST.Model;
using CRAVENEST.Repository.Interface;
using CRAVENEST.Utilities;
using CRAVENEST.Utilities.Eums;
using Microsoft.Extensions.Options;
using System.Data;
using System.Data.SqlClient;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;

namespace CRAVENEST.Repository.Concrete
{
    public class OrderRepository : IOrderRepository
    {
        private readonly string _connectionString;
        private readonly ILogger<OrderRepository> _logger;

        public OrderRepository(IOptions<AppSettings> appSettings, ILogger<OrderRepository> logger, IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _logger = logger;
        }

        public async Task<int> CreateOrder(Order order)
        {
            try
            {
                using var sqlConnection = new SqlConnection(_connectionString);
                using var sqlCommand = new SqlCommand("[dbo].[CreateOrder]", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                // Adding parameters for order creation
                sqlCommand.Parameters.Add(new SqlParameter("@CustomerName", SqlDbType.NVarChar, 100) { Value = order.CustomerName });
                sqlCommand.Parameters.Add(new SqlParameter("@CustomerEmail", SqlDbType.NVarChar, 100) { Value = order.CustomerEmail });
                sqlCommand.Parameters.Add(new SqlParameter("@TotalAmount", SqlDbType.Decimal) { Value = order.TotalAmount });
                sqlCommand.Parameters.Add(new SqlParameter("@SignUpId", SqlDbType.Int) { Value = order.SignUpId });

                // Serializing Order Items into JSON format for the stored procedure
                string orderItemsJson = JsonConvert.SerializeObject(order.Items);
                sqlCommand.Parameters.Add(new SqlParameter("@OrderItems", SqlDbType.NVarChar) { Value = orderItemsJson });

                var orderIdParam = sqlCommand.Parameters.Add("@OrderId", SqlDbType.Int);
                orderIdParam.Direction = ParameterDirection.Output;

                // Execute stored procedure
                await sqlConnection.OpenAsync();
                await sqlCommand.ExecuteNonQueryAsync();

                return (int)orderIdParam.Value; // Return the generated OrderId
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating order with Customer: {CustomerEmail}, TotalAmount: {TotalAmount}",
                                 order.CustomerEmail, order.TotalAmount);
                throw;  // Re-throw to handle at higher layers
            }
        }

        public async Task<Order> GetOrderById(int id)
        {
            try
            {
                using var sqlConnection = new SqlConnection(_connectionString);
                using var sqlCommand = new SqlCommand("[dbo].[GetOrderById]", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                sqlCommand.Parameters.Add(new SqlParameter("@OrderId", SqlDbType.Int) { Value = id });

                await sqlConnection.OpenAsync();
                using var reader = await sqlCommand.ExecuteReaderAsync();

                Order order = null;

                // Reading the first result set (Order details)
                if (await reader.ReadAsync())
                {
                    order = new Order
                    {
                        OrderId = (int)reader["OrderId"],
                        CustomerName = (string)reader["CustomerName"],
                        CustomerEmail = (string)reader["CustomerEmail"],
                        TotalAmount = (decimal)reader["TotalAmount"],
                        Status = (string)reader["Status"],
                        CreatedAt = (DateTime)reader["CreatedAt"],
                        UpdatedAt = reader["UpdatedAt"] as DateTime?,
                        SignUpId = (int)reader["SignUpId"],
                        Items = new List<OrderItem>()
                    };
                }

                // Move to the next result set (Order items)
                if (await reader.NextResultAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        // Add items to the order
                        order.Items.Add(new OrderItem
                        {
                            OrderItemId = (int)reader["OrderItemId"],
                            OrderId = (int)reader["OrderId"],
                            FoodItemId = (int)reader["FoodItemId"],
                            Quantity = (int)reader["Quantity"],
                            UnitPrice = (decimal)reader["UnitPrice"]
                        });
                    }
                }

                return order;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting order by id {id}");
                throw;
            }
        }


        public async Task<List<Order>> GetAllOrders()
        {
            var orders = new List<Order>();

            try
            {
                using var sqlConnection = new SqlConnection(_connectionString);
                using var sqlCommand = new SqlCommand("[dbo].[GetAllOrders]", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                await sqlConnection.OpenAsync();
                using var reader = await sqlCommand.ExecuteReaderAsync();

                Order currentOrder = null;

                while (await reader.ReadAsync())
                {
                    var orderId = (int)reader["OrderId"];

                    // Initialize the currentOrder if it's null or if we encounter a new order
                    if (currentOrder == null || currentOrder.OrderId != orderId)
                    {
                        if (currentOrder != null)
                        {
                            orders.Add(currentOrder);  // Add the previous order before moving to a new one
                        }

                        currentOrder = new Order
                        {
                            OrderId = orderId,
                            CustomerName = (string)reader["CustomerName"],
                            CustomerEmail = (string)reader["CustomerEmail"],
                            TotalAmount = (decimal)reader["TotalAmount"],
                            Status = (string)reader["Status"],
                            CreatedAt = (DateTime)reader["CreatedAt"],
                            UpdatedAt = reader["UpdatedAt"] as DateTime?,
                            SignUpId = (int)reader["SignUpId"],
                            Items = new List<OrderItem>()
                        };
                    }

                    // Add the order items
                    currentOrder.Items.Add(new OrderItem
                    {
                        OrderItemId = (int)reader["OrderItemId"],
                        OrderId = orderId,
                        FoodItemId = (int)reader["FoodItemId"],
                        FoodItemName = (string)reader["FoodItemName"],
                        Quantity = (int)reader["Quantity"],
                        UnitPrice = (decimal)reader["UnitPrice"]
                    });
                }

                if (currentOrder != null)
                {
                    orders.Add(currentOrder);  // Add the last order if present
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all orders");
                throw;
            }

            return orders;
        }

        public async Task<ResultStatus> UpdateOrderStatus(int id, string status)
        {
            try
            {
                using var sqlConnection = new SqlConnection(_connectionString);
                using var sqlCommand = new SqlCommand("[dbo].[UpdateOrderStatus]", sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                sqlCommand.Parameters.Add(new SqlParameter("@OrderId", SqlDbType.Int) { Value = id });
                sqlCommand.Parameters.Add(new SqlParameter("@Status", SqlDbType.NVarChar, 50) { Value = status });

                // Create a parameter to capture the return value from the stored procedure
                var returnValue = new SqlParameter
                {
                    ParameterName = "@ReturnValue",
                    SqlDbType = SqlDbType.Int,
                    Direction = ParameterDirection.ReturnValue
                };
                sqlCommand.Parameters.Add(returnValue);

                await sqlConnection.OpenAsync();
                await sqlCommand.ExecuteNonQueryAsync();

                // Get the return value, which is the number of rows affected
                int rowsAffected = (int)returnValue.Value;

                _logger.LogInformation("Order status update: OrderId {OrderId}, Status {Status}, RowsAffected: {RowsAffected}", id, status, rowsAffected);

                return rowsAffected > 0 ? ResultStatus.Success : ResultStatus.Failed;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating status for order with id {id}");
                return ResultStatus.Failed;
            }
        }
    }
}

