﻿namespace CRAVENEST.Utilities
{
    public class AppSettings
    {
        public required string FarmersDBConnection { get; set; }
    }
}
