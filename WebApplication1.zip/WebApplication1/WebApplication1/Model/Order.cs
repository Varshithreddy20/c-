﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;  // Make sure this is included

namespace CRAVENEST.Model
{
    public class Order
    {
        // Fields expected in the request
        public string? CustomerName { get; set; }  // Required in request
        public string? CustomerEmail { get; set; }  // Required in request
        public decimal TotalAmount { get; set; }  // Required in request
        public int SignUpId { get; set; }  // Required in request
        public List<OrderItem>? Items { get; set; }  // Required in request

        // Auto-handled by backend, not sent in the request
        [JsonIgnore]  // This field is not included in request/serialization
        public int OrderId { get; set; }

        [JsonIgnore]  // This field is not included in request/serialization
        public string Status { get; set; } = "Pending";  // Auto-handled by backend

        [JsonIgnore]  // This field is not included in request/serialization
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;  // Auto-handled by backend

        [JsonIgnore]  // This field is not included in request/serialization
        public DateTime? UpdatedAt { get; set; }  // Auto-handled by backend
    }

    public class OrderItem
    {
        // Fields expected in the request
        public int FoodItemId { get; set; }  // Required in request
        public int Quantity { get; set; }  // Required in request
        public decimal UnitPrice { get; set; }  // Required in request

        // Auto-handled by backend, not sent in the request
        [JsonIgnore]
        public int OrderItemId { get; set; }

        [JsonIgnore]
        public int OrderId { get; set; }

        [JsonIgnore]
        public string? FoodItemName { get; set; }
    }

}
