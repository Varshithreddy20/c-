﻿namespace CRAVENEST.Model
{
    public class User
    {
        public int? SignUpId { get; set; }
        public string? Name { get; set; } = string.Empty;
        public string? EmailId { get; set; } = string.Empty;
        public string? Password { get; set; } = string.Empty;
        public int Role { get; set; } = 1;
    }
    public class Login
    {
        public string? EmailId { get; set; } = string.Empty;
        public string? Password { get; set; } = string.Empty;
    }
}
