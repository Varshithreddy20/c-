﻿using CRAVENEST.Model;
using CRAVENEST.Repository.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CRAVENEST.Controllers
{
    [AllowAnonymous]
    [ApiController]
    [Route("api/[controller]")]
    public class UserController(IUserRepository userRepository, IJwtService jwtService) : ControllerBase
    {   
        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost("signup")]
        public IActionResult SignUp(User user)
        {
            var result = userRepository.SignUp(user);
            if (result == 1)
            {
                return Ok(new { Message = "User registered successfully" });
            }
            return BadRequest(new { Message = "User registration failed" });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="loginUser"></param>
        /// <returns></returns>
        [HttpPost("login")]
        public IActionResult Login([FromBody] User loginUser)
        {
            var (success, token, role) = userRepository.Login(loginUser.EmailId, loginUser.Password);

            if (success)
            {
                var generatedToken = jwtService.GenerateToken(token);

                // Return role along with token for redirection purposes
                return Ok(new { Token = generatedToken, Role = role });
            }
            return Unauthorized(new { Message = "Invalid credentials" });
        }

    }
}
