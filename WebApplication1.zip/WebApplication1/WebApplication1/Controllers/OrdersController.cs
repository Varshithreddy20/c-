﻿using Microsoft.AspNetCore.Mvc;
using CRAVENEST.Model;
using CRAVENEST.Service.Interface;
using CRAVENEST.Utilities.Eums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CRAVENEST.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrdersController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateOrder([FromBody] Order order)
        {
            // Ensure the order and its items are valid (but don't check for FoodItemName)
            if (!ModelState.IsValid || !order.Items.Any())
            {
                return BadRequest("Invalid order or no items included");
            }

            // Process the order by sending it to the service layer
            var orderId = await _orderService.CreateOrder(order);

            // Fetch the created order from the service (which should populate FoodItemName)
            var createdOrder = await _orderService.GetOrderById(orderId);

            return CreatedAtAction(nameof(GetOrder), new { id = orderId }, createdOrder);
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrder(int id)
        {
            var order = await _orderService.GetOrderById(id);
            if (order == null)
            {
                return NotFound();
            }
            return Ok(order);
        }

        [HttpGet]
        public async Task<IActionResult> GetAllOrders()
        {
            var orders = await _orderService.GetAllOrders();
            return Ok(orders);
        }

        [HttpPatch("{id}/status")]
        public async Task<IActionResult> UpdateOrderStatus(int id, [FromBody] string status)
        {
            var result = await _orderService.UpdateOrderStatus(id, status);
            return result == ResultStatus.Success ? NoContent() : NotFound();
        }
    }
}
