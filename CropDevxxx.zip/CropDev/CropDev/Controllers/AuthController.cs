﻿using CropDev.JwtInterface;
using CropDev.Models;
using CropDev.Repository.Interface;
using Microsoft.AspNetCore.Mvc;

namespace CropDev.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IJwtService _jwtService;

        public AuthController(IUserRepository userRepository, IJwtService jwtService)
        {
            _userRepository = userRepository;
            _jwtService = jwtService;
        }

        [HttpPost("signup")]
        public IActionResult SignUp(User user)
        {
            var result = _userRepository.SignUp(user);
            if (result == 1)
            {
                return Ok(new { Message = "User registered successfully" });
            }
            return BadRequest(new { Message = "User registration failed" });
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] User loginUser)
        {
            var (success, token) = _userRepository.Login(loginUser.EmailId, loginUser.Password);
            if (success)
            {
                return Ok(new { Token = token });
            }
            return Unauthorized(new { Message = "Invalid credentials" });
        }
    }
}
